# Site — Dra. Michele Carneiro (Nutrição Integrativa)

Este pacote contém um site estático (HTML/CSS/JS) pronto para publicar.

## Como editar (sem programar)
### 1) Trocar fotos
- Coloque suas imagens em: `assets/images/`
- Depois, edite o HTML da página desejada (ex.: `index.html`) e troque o caminho da imagem.

### 2) Adicionar/editar e-books e produtos
- Coloque os PDFs em: `assets/ebooks/`
- Abra e edite: `data/produtos.json`
- Cada item tem:
  - `titulo`
  - `descricao`
  - `tag` (ex.: "E-book", "PDF • Protocolo")
  - `link` (ex.: "assets/ebooks/meu-ebook.pdf" ou link do checkout Hotmart)

## Publicar (3 jeitos fáceis)
### Opção A — Netlify (mais simples)
1. Crie conta no Netlify
2. Arraste a pasta do site (ou o .zip) para o painel
3. Pronto — ele publica e te dá um link

### Opção B — Vercel
1. Suba o site em um repositório (GitHub)
2. Import no Vercel
3. Deploy

### Opção C — Hospedagem tradicional
1. Envie todos os arquivos via FTP para a pasta `public_html`
2. Teste abrindo o domínio

## Observação
Se você quiser aceitar pagamentos e entregar e-books automaticamente, o caminho mais simples é:
- Vender via Hotmart/Eduzz/Monetizze/MercadoPago
- Colocar o link do checkout no `data/produtos.json`
